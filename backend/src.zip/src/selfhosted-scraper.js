/**
 * FrameFinder public-page collector. No authentication bypass or private APIs.
 * Zero items is valid when public pages are inaccessible or have no creatives.
 */
import { chromium } from 'playwright';

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const clean = v => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, 120);
const BLOCK = /log in to continue|login to continue|sign up to see|captcha|unusual activity|temporarily blocked|automated requests|confirm your identity/i;
const positive = (value, fallback, cap) => {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? Math.min(Math.floor(n), cap) : fallback;
};
function httpUrl(value) {
  try {
    const u = new URL(value);
    return ['https:', 'http:'].includes(u.protocol) ? u.href : '';
  } catch { return ''; }
}
function instagramFromRaw(item) {
  const value = httpUrl(item?.url);
  const m = value.match(/^https?:\/\/(?:www\.)?instagram\.com\/reel\/([A-Za-z0-9_-]+)/i);
  if (!m) return null;
  const id = m[1];
  return {
    platform: 'instagram', id, identity: `instagram:reel:${id}`,
    url: `https://www.instagram.com/reel/${id}/`,
    caption: clean(item.caption), thumbnail: httpUrl(item.thumbnail),
    postedAt: null, videoUrl: null, isConfirmedReel: true, mediaType: 'video'
  };
}
function metaFromRaw(item) {
  const id = String(item?.id || '');
  // Video evidence must come from a visible media element or a play-video control
  // associated with the same identified ad card, never from the query alone.
  if (!/^\d{6,25}$/.test(id) || item?.hasVideo !== true) return null;
  return {
    platform: 'meta', id, identity: `meta:${id}`,
    url: `https://www.facebook.com/ads/library/?id=${id}`,
    caption: clean(item.caption), thumbnail: httpUrl(item.thumbnail),
    videoUrl: httpUrl(item.videoUrl) || null, postedAt: null, mediaType: 'video'
  };
}
export function normalizePublicItems(platform, items) {
  if (!['instagram', 'meta'].includes(platform)) throw Error('Unsupported platform');
  if (!Array.isArray(items)) return [];
  const seen = new Map();
  for (const item of items) {
    const normalized = platform === 'instagram' ? instagramFromRaw(item) : metaFromRaw(item);
    if (normalized) seen.set(normalized.identity, normalized);
  }
  return [...seen.values()];
}

async function pageDiagnostics(page, platform) {
  const body = await page.locator('body').innerText({ timeout: 7000 }).catch(() => '');
  const url = page.url();
  const title = await page.title().catch(() => '');
  const loginRedirect = /instagram\.com\/accounts\/login|instagram\.com\/challenge|facebook\.com\/login/i.test(url);
  const isBlocked = loginRedirect || BLOCK.test(body.slice(0, 5000));
  const counts = await page.evaluate(() => ({
    reelLinks: document.querySelectorAll('a[href*="/reel/"]').length,
    adLinks: document.querySelectorAll('a[href*="ads/library/"]').length,
    videoElements: document.querySelectorAll('video').length,
    images: document.querySelectorAll('img').length,
    iframeElements: document.querySelectorAll('iframe').length
  })).catch(() => ({}));
  console.log(JSON.stringify({ event: 'selfhosted_page', platform, url, title: title.slice(0, 120), blocked: isBlocked, bodyLength: body.length, ...counts, bodyPreview: process.env.SELFHOSTED_DEBUG === 'true' ? body.slice(0, 260) : undefined }));
  if (isBlocked) throw Error(`${platform}: public page requires login or is blocked`);
  return { bodyLength: body.length, ...counts };
}

async function instagramSearch(page, query, scrolls) {
  const tag = (clean(query).toLowerCase().match(/[a-z0-9]+/g) || []).join('').slice(0, 45);
  if (!tag) return [];
  const url = `https://www.instagram.com/explore/tags/${encodeURIComponent(tag)}/`;
  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
  await sleep(1500);
  await pageDiagnostics(page, 'instagram');
  const found = new Map();
  for (let i = 0; i <= scrolls; i++) {
    const records = await page.locator('a[href*="/reel/"]').evaluateAll(links => links.map(a => {
      const img = a.querySelector('img') || a.parentElement?.querySelector('img');
      return { url: a.href, thumbnail: img?.currentSrc || img?.src || '', caption: img?.alt || a.getAttribute('aria-label') || '' };
    })).catch(() => []);
    for (const record of records) found.set(record.url, record);
    if (i < scrolls) { await page.mouse.wheel(0, 1000); await sleep(800); }
  }
  return [...found.values()];
}

// Extract only ad cards with an actual Library ID and concrete video evidence.
// Handles cards that display "Library ID: ..." but have no permalink anchor.
async function visibleMetaCards(page) {
  return page.evaluate(() => {
    const candidates = new Map();
    const nodes = [...document.querySelectorAll('a, span, div')].filter(el => {
      if (el.children.length > 4) return false;
      const text = (el.innerText || '').trim();
      return /Library ID\s*:?\s*\d{6,25}/i.test(text) && text.length < 160;
    });
    for (const node of nodes.slice(0, 250)) {
      const m = (node.innerText || '').match(/Library ID\s*:?\s*(\d{6,25})/i);
      if (!m) continue;
      // Move from ID label to a bounded visible ad-card ancestor.
      let card = node;
      for (let i = 0; i < 6 && card?.parentElement; i++) {
        if ((card.innerText || '').length >= 100) break;
        card = card.parentElement;
      }
      if (!card || (card.innerText || '').length > 6000) continue;
      const video = card.querySelector('video');
      // Some ad players render poster images with an explicit play-video control.
      const playControl = card.querySelector('[aria-label="Play video"], [aria-label="Play Video"], [aria-label*="Play video"], [data-testid*="play-video"]');
      if (!video && !playControl) continue;
      const img = card.querySelector('img');
      const thumb = video?.poster || img?.currentSrc || img?.src || '';
      candidates.set(m[1], {
        id: m[1], hasVideo: true, thumbnail: thumb,
        videoUrl: video?.currentSrc || video?.src || '',
        caption: (card.innerText || '').slice(0, 500)
      });
    }
    // Some layouts expose a permalink without the "Library ID" heading.
    for (const a of [...document.querySelectorAll('a[href*="ads/library/"]')]) {
      let id = '';
      try { id = new URL(a.href).searchParams.get('id') || ''; } catch {}
      if (!/^\d{6,25}$/.test(id) || candidates.has(id)) continue;
      let card = a;
      for (let i = 0; i < 6 && card?.parentElement; i++) {
        if (card.querySelector('video, [aria-label="Play video"], [aria-label="Play Video"]')) break;
        card = card.parentElement;
      }
      if (!card || (card.innerText || '').length > 6000) continue;
      const video = card.querySelector('video');
      const play = card.querySelector('[aria-label="Play video"], [aria-label="Play Video"]');
      if (!video && !play) continue;
      const img = card.querySelector('img');
      candidates.set(id, {
        id, hasVideo: true, thumbnail: video?.poster || img?.currentSrc || img?.src || '',
        videoUrl: video?.currentSrc || video?.src || '', caption: (card.innerText || '').slice(0, 500)
      });
    }
    return [...candidates.values()];
  });
}
async function metaSearch(page, query, scrolls) {
  const url = new URL('https://www.facebook.com/ads/library/');
  url.searchParams.set('active_status', 'all');
  url.searchParams.set('ad_type', 'all');
  url.searchParams.set('country', process.env.SELFHOSTED_META_COUNTRY || 'US');
  url.searchParams.set('media_type', 'video');
  url.searchParams.set('q', clean(query));
  url.searchParams.set('search_type', 'keyword_unordered');
  await page.goto(url.href, { waitUntil: 'domcontentloaded', timeout: 30000 });
  await sleep(1600);
  const initial = await pageDiagnostics(page, 'meta');
  const map = new Map();
  for (let i = 0; i <= scrolls; i++) {
    const records = await visibleMetaCards(page).catch(() => []);
    for (const r of records) map.set(r.id, r);
    if (i < scrolls) { await page.mouse.wheel(0, 950); await sleep(1000); }
  }
  console.log(JSON.stringify({ event: 'meta_extraction_diagnostic', bodyLength: initial.bodyLength, videoElements: await page.locator('video').count().catch(() => 0), extractedVideoAds: map.size, note: map.size ? 'Visible video evidence found' : 'No video ad creatives found in public rendered DOM; page may be restricted or layout unsupported' }));
  return [...map.values()];
}

export async function collectSelfHosted(platform, query, offset = 0, limit = 30) {
  if (!['instagram', 'meta'].includes(platform)) throw Error('Unknown platform');
  if (!clean(query)) throw Error('Search query required');
  if (offset !== 0) throw Error('Self-hosted collector does not provide stable pagination offsets');
  let browser;
  try {
    browser = await chromium.launch({ headless: process.env.SELFHOSTED_HEADLESS !== 'false' });
    const context = await browser.newContext({ viewport: { width: 1365, height: 900 }, locale: 'en-US' });
    const page = await context.newPage();
    page.setDefaultTimeout(10000);
    const scrolls = positive(process.env.SELFHOSTED_SCROLLS, 4, 12);
    const raw = platform === 'instagram' ? await instagramSearch(page, query, scrolls) : await metaSearch(page, query, scrolls);
    const records = normalizePublicItems(platform, raw).slice(0, positive(limit, 30, 100));
    console.log(JSON.stringify({ event: 'selfhosted_batch', platform, query: clean(query), rawCount: raw.length, normalizedCount: records.length, withThumbnails: records.filter(v => v.thumbnail).length }));
    return records;
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}
