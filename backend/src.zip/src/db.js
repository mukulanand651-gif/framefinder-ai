import pg from 'pg';
import {config} from './settings.js';
export const pool = new pg.Pool({connectionString:config.databaseUrl,ssl:config.databaseSsl?{rejectUnauthorized:true}:false,max:8});
export async function initDb(){await pool.query(`
CREATE TABLE IF NOT EXISTS searches(id uuid PRIMARY KEY, input text NOT NULL, status text NOT NULL DEFAULT 'queued', stage text NOT NULL DEFAULT 'Queued', product jsonb, error text, results jsonb NOT NULL DEFAULT '[]'::jsonb, issues jsonb NOT NULL DEFAULT '[]'::jsonb, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now());
ALTER TABLE searches ADD COLUMN IF NOT EXISTS candidate_previews jsonb NOT NULL DEFAULT '[]'::jsonb;
CREATE TABLE IF NOT EXISTS seen_videos(platform text NOT NULL, identity text NOT NULL, search_id uuid NOT NULL REFERENCES searches(id), fingerprint text, created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(platform,identity));
CREATE INDEX IF NOT EXISTS idx_seen_fingerprint ON seen_videos(platform,fingerprint);
CREATE INDEX IF NOT EXISTS idx_searches_created ON searches(created_at DESC);
CREATE TABLE IF NOT EXISTS product_catalog(source_url text PRIMARY KEY,title text NOT NULL,description text NOT NULL DEFAULT '',brand text NOT NULL DEFAULT '',model text NOT NULL DEFAULT '',image text NOT NULL,updated_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS product_cache(cache_key text PRIMARY KEY, value jsonb NOT NULL, updated_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS vision_score_cache(cache_key text PRIMARY KEY, value jsonb NOT NULL, updated_at timestamptz NOT NULL DEFAULT now());
`)}
export const updateSearch=async(id,fields)=>{const entries=Object.entries(fields);if(!entries.length)return;await pool.query(`UPDATE searches SET ${entries.map(([k],i)=>`${k}=$${i+2}`).join(',')},updated_at=now() WHERE id=$1`,[id,...entries.map(([,v])=>v)])};
