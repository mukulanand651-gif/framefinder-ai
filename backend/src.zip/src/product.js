import { lookup } from 'node:dns/promises';
import { isIP } from 'node:net';
import * as cheerio from 'cheerio';
import { pool } from './db.js';
import { hash } from './core.js';
import { discoverProduct } from './product-discovery.js';

function blockedIp(ip) {
  if (isIP(ip) === 4) {
    const p = ip.split('.').map(Number);
    return p[0] === 0 || p[0] === 10 || p[0] === 127 || p[0] >= 224 ||
      (p[0] === 169 && p[1] === 254) || (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
      (p[0] === 192 && p[1] === 168) || (p[0] === 100 && p[1] >= 64 && p[1] <= 127) ||
      (p[0] === 198 && [18,19].includes(p[1]));
  }
  const s=ip.toLowerCase();
  return s==='::1'||s==='::'||s.startsWith('fc')||s.startsWith('fd')||s.startsWith('fe80')||s.startsWith('::ffff:');
}
export async function safeUrl(s) {
  let u;
  try { u = new URL(s); } catch { throw Error('Invalid product or image URL'); }
  if (!['https:','http:'].includes(u.protocol) || u.username || u.password ||
    (u.port && !['80','443'].includes(u.port)) || u.hostname==='localhost' || u.hostname.endsWith('.local')) throw Error('Unsafe product or image URL');
  const addresses = await lookup(u.hostname,{all:true,verbatim:true});
  if (!addresses.length || addresses.some(x=>blockedIp(x.address))) throw Error('URL resolves to unsafe address');
  return u;
}
// Follow redirects manually, validating each hop. Bound response size.
export async function publicFetch(address,{maxBytes=4_000_000,timeoutMs=15000,accept='*/*'}={}) {
  let url = await safeUrl(address);
  for(let hops=0;hops<5;hops++) {
    const response = await fetch(url,{redirect:'manual',signal:AbortSignal.timeout(timeoutMs),headers:{'Accept':accept,'User-Agent':'Mozilla/5.0 (compatible; FrameFinder/1.0)'}});
    if ([301,302,303,307,308].includes(response.status)) {
      const location=response.headers.get('location');
      if(!location) throw Error('Redirect missing location');
      url=await safeUrl(new URL(location,url).href);
      continue;
    }
    if(!response.ok) throw Error(`Remote HTTP ${response.status}`);
    if(Number(response.headers.get('content-length')||0)>maxBytes) throw Error('Remote response too large');
    const chunks=[];let size=0;
    if(!response.body) throw Error('Remote response empty');
    for await(const chunk of response.body) {
      size+=chunk.byteLength;
      if(size>maxBytes) { await response.body.cancel().catch(()=>{}); throw Error('Remote response too large'); }
      chunks.push(Buffer.from(chunk));
    }
    return {body:Buffer.concat(chunks),mime:(response.headers.get('content-type')||'').split(';')[0].toLowerCase(),url:url.href};
  }
  throw Error('Too many redirects');
}
const absolute=(v,base)=>{try{return v?new URL(typeof v==='string'?v:v?.url||'',base).href:''}catch{return ''}};
function findProductJsonLd($) {
  const nodes=[];
  const walk=x=>{if(!x||typeof x!=='object')return;if(Array.isArray(x)){x.forEach(walk);return;}if(x['@type']==='Product'||(Array.isArray(x['@type'])&&x['@type'].includes('Product')))nodes.push(x);if(x['@graph'])walk(x['@graph']);};
  $('script[type="application/ld+json"]').each((_,el)=>{try{walk(JSON.parse($(el).html()||'null'))}catch{}});
  return nodes[0];
}
export async function productFrom(input,uploadedImage) {
  const raw=String(input||'').trim();
  const isUrl=/^https?:\/\//i.test(raw);
  const key='product:'+hash(raw);
  const cache=await pool.query("SELECT value FROM product_cache WHERE cache_key=$1 AND updated_at > now()-interval '7 days'",[key]);
  if(cache.rows[0]&&!uploadedImage && cache.rows[0].value?.image && (isUrl || cache.rows[0].value.referenceSource==='auto-discovered')) {
    const saved = cache.rows[0].value;
    if(isUrl && saved.sourceUrl && saved.title) await pool.query(`INSERT INTO product_catalog(source_url,title,description,brand,model,image) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(source_url) DO UPDATE SET title=EXCLUDED.title,description=EXCLUDED.description,brand=EXCLUDED.brand,model=EXCLUDED.model,image=EXCLUDED.image,updated_at=now()`,[saved.sourceUrl,saved.title,saved.description||'',saved.brand||'',saved.model||'',saved.image]);
    return {...saved,cacheHit:true};
  }
  let product={title:raw,description:'',image:uploadedImage||'',url:null,sourceUrl:null,attributes:null,queries:[]};
  if(isUrl){
    const page=await publicFetch(raw,{maxBytes:900000,accept:'text/html'});
    if(!page.mime.includes('text/html'))throw Error('Expected an HTML product page');
    const $=cheerio.load(page.body.toString('utf8'));
    const meta=k=>$(`meta[property="${k}"],meta[name="${k}"]`).first().attr('content')||'';
    const structured=findProductJsonLd($);
    const sourceImage=structured?.image;
    const firstImage=Array.isArray(sourceImage)?sourceImage[0]:sourceImage;
    const brand=structured?.brand;
    product={...product,title:String(structured?.name||meta('og:title')||$('h1').first().text().trim()||$('title').text()||raw).trim(),description:String(structured?.description||meta('og:description')||meta('description')||'').replace(/<[^>]*>/g,'').slice(0,2400),image:uploadedImage||absolute(firstImage,page.url)||absolute(meta('og:image'),page.url)||absolute($('img').first().attr('src'),page.url),url:page.url,sourceUrl:page.url,brand:typeof brand==='string'?brand:brand?.name||'',model:structured?.model||'',sku:structured?.sku||''};
} else if (!uploadedImage) {
  const discovery = await discoverProduct(raw, pool);

  const candidates = Array.isArray(discovery.candidates)
    ? discovery.candidates
    : [];

  product = {
    ...product,
    productCandidates: candidates,
    discoveryIssue: discovery.issue || null,
    referenceSource: 'keyword',
    referenceConfidence: null
  };

  const selected = discovery.selected;

  if (
    selected?.image &&
    selected?.sourceUrl &&
    selected?.title
  ) {
    product = {
      ...product,
      title: selected.title,
      description: selected.description || '',
      image: selected.image,
      url: selected.sourceUrl,
      sourceUrl: selected.sourceUrl,
      brand: selected.brand || '',
      model: selected.model || '',
      sku: selected.sku || '',
      referenceSource: 'auto-discovered',
      referenceConfidence: selected.confidence ?? null,
      productCandidates: candidates
    };
  } else {
    console.log(JSON.stringify({
      event: 'product_selection_required',
      keyword: raw,
      candidatesFound: candidates.length,
      reason: discovery.issue ||
        'No unambiguous product reference image'
    }));
  }
}
  if (isUrl && product.title && product.image && product.sourceUrl) {
    await pool.query(`INSERT INTO product_catalog(source_url,title,description,brand,model,image) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(source_url) DO UPDATE SET title=EXCLUDED.title,description=EXCLUDED.description,brand=EXCLUDED.brand,model=EXCLUDED.model,image=EXCLUDED.image,updated_at=now()`,[product.sourceUrl,product.title,product.description,product.brand||'',product.model||'',product.image]);
  }
  if(!uploadedImage && (isUrl || product.image)) await pool.query('INSERT INTO product_cache(cache_key,value) VALUES($1,$2) ON CONFLICT(cache_key) DO UPDATE SET value=EXCLUDED.value,updated_at=now()',[key,JSON.stringify(product)]);
  return product;
}
