import { fallbackScore, hash } from './core.js';
import { publicFetch } from './product.js';

const key = () => process.env.GEMINI_API_KEY;
const model = () => process.env.GEMINI_MODEL || 'gemini-3.5-flash-lite';
const results = new Map();
let nextCall = 0;
let queue = Promise.resolve();
let unavailableUntil = 0;
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
const errorText = e => String(e?.message || e).slice(0, 240);

async function imagePart(input) {
  if (!input || typeof input !== 'string') throw Error('Image missing');
  const inline = /^data:(image\/(?:jpeg|png|webp));base64,([a-zA-Z0-9+/=]+)$/i.exec(input);
  if (inline) {
    if (inline[2].length > 5_400_000) throw Error('Reference image too large');
    return { inline_data: { mime_type: inline[1].toLowerCase(), data: inline[2] } };
  }
  const { body, mime } = await publicFetch(input, { maxBytes: 4_000_000, timeoutMs: 20000, accept: 'image/*' });
  if (!['image/jpeg','image/png','image/webp'].includes(mime)) throw Error(`Unsupported image type: ${mime || 'missing'}`);
  return { inline_data: { mime_type: mime, data: body.toString('base64') } };
}

// One shared local worker limiter. For multiple workers, use a central limiter.
function schedule(task) {
  const pending = queue.then(async () => {
    if (Date.now() < unavailableUntil) throw Error('Gemini quota temporarily unavailable');
    const wait = Math.max(0, nextCall - Date.now());
    if (wait) await delay(wait);
    nextCall = Date.now() + Math.max(6500, Number(process.env.GEMINI_MIN_INTERVAL_MS || 7000));
    return task();
  });
  queue = pending.catch(() => {});
  return pending;
}

async function generate(prompt, images, tokens = 350) {
  if (!key()) throw Error('GEMINI_API_KEY not configured');
  if (Date.now() < unavailableUntil) throw Error('Gemini quota temporarily unavailable');
  // Download before occupying the API rate-limit slot.
  const parts = [{ text: prompt }, ...(await Promise.all(images.map(imagePart)))];
  return schedule(async () => {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model())}:generateContent`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'x-goog-api-key': key(), 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents: [{ role: 'user', parts }], generationConfig: { responseMimeType: 'application/json', maxOutputTokens: tokens, temperature: 0.1 } }),
      signal: AbortSignal.timeout(Math.min(90000, Math.max(15000, Number(process.env.GEMINI_REQUEST_TIMEOUT_MS || 45000))))
    });
    if (!response.ok) {
      const detail = (await response.text()).slice(0, 180);
      if ([400, 401, 403, 404, 429].includes(response.status)) unavailableUntil = Date.now() + (response.status === 429 ? 90_000 : 10 * 60_000);
      throw Error(`Gemini HTTP ${response.status}: ${detail}`);
    }
    const data = await response.json();
    const content = (data.candidates?.[0]?.content?.parts || []).map(x => x.text || '').join('');
    if (!content) throw Error('Gemini returned no response');
    return JSON.parse(content);
  });
}

export function visionAvailable() { return Boolean(key()) && Date.now() >= unavailableUntil; }
const unknown = () => ({ productType: 'unknown', colors: [], graphics: [], logos: [], material: 'unknown', shape: 'unknown', text: [] });
export async function analyze(product) {
  if (!product.image) return { ...product, attributes: unknown(), queries: [product.title], visionVerified: false, visionIssue: 'No product image supplied' };
  try {
    const out = await generate(`Read only visible product attributes for ${JSON.stringify(product.title)}. Return JSON {productType:string,colors:string[],graphics:string[],logos:string[],material:string,shape:string,text:string[],queries:string[]} with three useful specific searches. Do not invent unseen details.`, [product.image], 500);
    const attributes={...unknown(),...out};
    const generatedDescription=[attributes.productType,...(attributes.colors||[]),...(attributes.graphics||[]),...(attributes.logos||[]),...(attributes.text||[])].filter(Boolean).join(', ');
    return { ...product, attributes, generatedDescription, queries: [...new Set([product.title, ...(Array.isArray(out.queries) ? out.queries : [])])].slice(0, 5), visionVerified: true };
  } catch (e) {
    console.warn(JSON.stringify({ event: 'vision_analysis_error', error: errorText(e) }));
    return { ...product, attributes: unknown(), queries: [product.title], visionVerified: false, visionIssue: errorText(e) };
  }
}
export async function score(product, video) {
  if (!product.image || !video.thumbnail || !visionAvailable()) return { ...fallbackScore(product, video), verified: false, reason: 'No accessible visual verification; text-only estimate.' };
  const cacheKey = hash(`${model()}|${hash(product.image)}|${video.platform}|${video.identity}|${video.thumbnail}`);
  if (results.has(cacheKey)) return results.get(cacheKey);
  try {
    const out = await generate(`Compare first image REFERENCE PRODUCT with second image VIDEO THUMBNAIL, without inferring unseen frames. Product: ${product.title}. Candidate: ${video.caption}. Return JSON {"score":integer 0..100,"reason":string}. Require matching distinctive graphics/logos for high scores; use <=59 for weak/uncertain matches.`, [product.image, video.thumbnail], 200);
    const result = { score: Math.max(0, Math.min(100, Math.round(Number(out.score) || 0))), reason: String(out.reason || 'No reason supplied').slice(0, 280), verified: true };
    results.set(cacheKey, result);
    if (results.size > 500) results.delete(results.keys().next().value);
    return result;
  } catch (e) {
    console.warn(JSON.stringify({ event: 'vision_score_error', platform: video.platform, error: errorText(e) }));
    return { ...fallbackScore(product, video), verified: false, reason: `Visual verification unavailable: ${errorText(e)}` };
  }
}
