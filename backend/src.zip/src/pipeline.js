import { pool, updateSearch } from './db.js';
import { productFrom } from './product.js';
import { analyze, score, visionAvailable } from './vision.js';
import { collect } from './collectors.js';
import { isNearDuplicate, fingerprint, hash } from './core.js';
import { config } from './settings.js';

const posInt = (value, fallback, max) => {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? Math.min(Math.floor(n), max) : fallback;
};
const passes = () => posInt(process.env.MAX_SOURCE_PASSES, 2, 5);
const checks = () => posInt(process.env.MAX_VISION_CHECKS_PER_SOURCE, 8, 40);
const limit = () => posInt(process.env.APIFY_CANDIDATE_LIMIT, 30, 100);
const target = () => posInt(process.env.RESULTS_PER_SOURCE, 20, 20);
const previewLimit = () => posInt(process.env.UNVERIFIED_PREVIEW_LIMIT, 20, 40);
const stage = (id, name) => updateSearch(id, { stage: name });
const clean = text => String(text || '').replace(/[^a-zA-Z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
const words = text => clean(text).toLowerCase().split(' ').filter(x => x.length > 2);
const invalid = new Set(['unknown', 'undefined', 'null', 'none', 'product', 'n a']);
const safeArray = value => Array.isArray(value) ? value : [];

// Brand/model and page title are prioritized on BOTH sources.
// Broad category terms only apply to generic keyword searches, not named products.
export function buildSourceQueries(platform, product) {
  const title = clean(product.title);
  const brand = clean(product.brand || product.attributes?.brand);
  const model = clean(product.model || product.attributes?.model);
  const type = clean(product.attributes?.productType);
  const a = product.attributes || {};
  const textFeatures = [...safeArray(a.text), ...safeArray(a.logos)].map(clean).filter(Boolean);
  const exact = [
    brand && model && `${brand} ${model}`,
    title,
    brand && type && `${brand} ${type}`,
    ...textFeatures.filter(t => t.length > 4).slice(0, 2).map(t => brand ? `${brand} ${t}` : t),
    ...safeArray(product.queries)
  ];
  const isBranded = Boolean(brand || model || product.sourceUrl || product.url || title.split(' ').length >= 5);
  const broad = [];
  if (!isBranded) {
    if (/t\s?shirt|tshirt|graphic tee|printed tee/i.test(title)) broad.push('oversized graphic tee', 'graphic tees');
    else if (/chocolate|cocoa/i.test(title)) broad.push('dark chocolate', 'chocolate bars');
    else if (/running shoe|sneaker|trainer/i.test(title)) broad.push('running shoes', 'sneakers');
  }
  const result = [...new Set([...exact, ...broad].map(clean).filter(q => q.length >= 3 && !invalid.has(q.toLowerCase())))];
  return result.slice(0, 5);
}

function relevance(product, video) {
  const text = clean([video.caption, video.title, video.adCopy].filter(Boolean).join(' ')).toLowerCase();
  const titleWords = words(product.title).filter(x => !['mens', 'womens', 'with', 'the', 'shoe', 'shoes', 'runner', 'running'].includes(x));
  const brand = clean(product.brand || product.attributes?.brand).toLowerCase();
  const model = clean(product.model || product.attributes?.model).toLowerCase();
  let points = titleWords.reduce((n, w) => n + (text.includes(w) ? 8 : 0), 0);
  if (brand && text.includes(brand)) points += 60;
  if (model && text.includes(model)) points += 70;
  const distinctive = [...safeArray(product.attributes?.text), ...safeArray(product.attributes?.logos)];
  for (const term of distinctive) if (clean(term).length >= 5 && text.includes(clean(term).toLowerCase())) points += 25;
  return points;
}

function terminal(error) {
  const message = String(error?.message || error);
  return /(?:HTTP|Provider HTTP)\s*(401|402|403)\b|insufficient credits|monthly usage hard limit|quota exceeded|API_KEY missing|configuration missing|invalid .*actor JSON/i.test(message);
}

function stripped(video, match, verificationStatus) {
  const item = { ...video, match, verificationStatus, fingerprint: fingerprint(video) };
  delete item.raw;
  delete item.videoUrl;
  return item;
}

async function getCachedScore(product, video) {
const key = hash([
  'thumbnail-match-v2',
  process.env.GEMINI_MODEL || 'default',
  hash(product.image),
  video.identity,
  video.thumbnail
].join('|'));
  const result = await pool.query("SELECT value FROM vision_score_cache WHERE cache_key=$1 AND updated_at > now()-interval '30 days'", [key]);
  return { key, match: result.rows[0]?.value?.verified === true ? result.rows[0].value : null };
}
async function putCachedScore(key, match) {
  if (!match?.verified) return;
  await pool.query('INSERT INTO vision_score_cache(cache_key,value) VALUES($1,$2) ON CONFLICT(cache_key) DO UPDATE SET value=EXCLUDED.value,updated_at=now()', [key, JSON.stringify(match)]);
}

async function runSource(id, platform, product) {
  const issues = [], chosen = [], previews = [], collected = [], seenIds = new Set();
  const stats = { normalizedCandidates: 0, duplicateIds: 0, nearDuplicates: 0, previouslySeen: 0, rejectedNonReels: 0, rejectedLowRelevance: 0, belowThreshold: 0, unverified: 0, accepted: 0, visionChecks: 0, cacheHits: 0, passes: 0 };
  const queries = buildSourceQueries(platform, product);
  const requireReels = process.env.REQUIRE_CONFIRMED_REELS !== 'false';
  const minRelevance = Number(process.env.MIN_TEXT_RELEVANCE || 0);
  const hasBrand = Boolean(clean(product.brand || product.attributes?.brand));
  const strongTextRequired = process.env.STRICT_BRAND_TEXT_MATCH === 'true';
  const rounds = Math.min(queries.length, passes());

  // Collect ALL query passes before consuming limited Gemini checks.
  for (let round = 0; round < rounds; round++) {
    const query = queries[round];
    stats.passes++;
    await stage(id, `Searching ${platform}: ${round + 1}/${rounds}`);
    let batch;
    try { batch = await collect(platform, query, 0, limit()); }
    catch (e) {
      const message = String(e?.message || e);
      issues.push(`${platform}: query ${round + 1} failed: ${message.slice(0, 180)}`);
      if (terminal(e)) break;
      continue;
    }
    if (!Array.isArray(batch)) { issues.push(`${platform}: invalid collector response`); continue; }
    stats.normalizedCandidates += batch.length;
    console.log(JSON.stringify({ event: 'source_pass', platform, searchId: id, query, count: batch.length }));
    for (const v of batch) {
      if (!v?.identity || !v?.url || !v?.thumbnail) continue;
      if (seenIds.has(v.identity)) { stats.duplicateIds++; continue; }
      seenIds.add(v.identity);
      if (platform === 'instagram' && requireReels && v.isConfirmedReel !== true) { stats.rejectedNonReels++; continue; }
      if (collected.some(existing => isNearDuplicate(existing, v))) { stats.nearDuplicates++; continue; }
      const textRank = relevance(product, v);
      if (strongTextRequired && hasBrand && textRank < 60) { stats.rejectedLowRelevance++; continue; }
      if (textRank < minRelevance) { stats.rejectedLowRelevance++; continue; }
      collected.push({ ...v, _textRank: textRank });
    }
  }

  // Rank across ALL passes, not just the earliest actor results.
  collected.sort((a, b) => b._textRank - a._textRank);
  await stage(id, `Verifying ${platform} candidates`);
  const previewIdentity = new Set();
  const addPreview = (video, reason) => {
    if (previews.length >= previewLimit() || previewIdentity.has(video.identity)) return;
    previewIdentity.add(video.identity);
    previews.push(stripped(video, { score: null, verified: false, reason }, 'unverified'));
  };

  for (const video of collected) {
    if (chosen.length >= target()) break;
    const fp = fingerprint(video);
    const previous = await pool.query('SELECT 1 FROM seen_videos WHERE platform=$1 AND (identity=$2 OR fingerprint=$3) LIMIT 1', [platform, video.identity, fp]);
    if (previous.rowCount) { stats.previouslySeen++; continue; }
    if (!product.image || !product.visionVerified || !visionAvailable()) {
        console.log(JSON.stringify({
    event: 'visual_check_skipped',
    platform,
    searchId: id,
    identity: video.identity,
    productVisionVerified:
      Boolean(product.visionVerified),
    hasProductImage: Boolean(product.image),
    hasThumbnail: Boolean(video.thumbnail),
    visionAvailable: visionAvailable()
  }));
      stats.unverified++;
      addPreview(video, 'Reference product image or AI analysis unavailable');
      continue;
    }
    let match;
    try {
      const cached = await getCachedScore(product, video);
      if (cached.match) { match = cached.match; stats.cacheHits++; }
      else {
        if (stats.visionChecks >= checks()) { stats.unverified++; addPreview(video, 'Visual verification budget reached'); continue; }
        stats.visionChecks++;
        match = config.demo ? { verified: false, score: null, reason: 'Demo only' } : await score(product, video);
        await putCachedScore(cached.key, match);
      }
    } catch (e) {
      stats.unverified++;
      addPreview(video, `Visual verification error: ${String(e.message || e).slice(0, 100)}`);
      continue;
    }
    console.log(JSON.stringify({ event: 'candidate_scored', platform, searchId: id, identity: video.identity, score: match?.score, verified: match?.verified, reason: String(match?.reason || '').slice(0, 150) }));
    if (match?.verified !== true || !Number.isFinite(Number(match.score))) { stats.unverified++; addPreview(video, match?.reason || 'Visual verification unavailable'); continue; }
    if (Number(match.score) < config.minScore) { stats.belowThreshold++; continue; }
    chosen.push(stripped(video, match, 'verified'));
    stats.accepted++;
  }
  if (chosen.length < target()) issues.push(`${platform}: ${chosen.length}/${target()} verified matches; ${stats.normalizedCandidates} collected, ${stats.visionChecks} visual checks, ${stats.belowThreshold} rejected below threshold, ${previews.length} unverified previews.`);
  console.log(JSON.stringify({ event: 'source_filter_summary', platform, searchId: id, ...stats, previewCount: previews.length, issues }));
  return { chosen, candidatesPreview: previews, issues };
}

async function prepareProduct(job) {
  const product = await productFrom(job.input, job.image);
  
console.log(JSON.stringify({
  event: 'product_reference_resolved',
  inputType: /^https?:\/\//i.test(job.input || '')
    ? 'url'
    : 'keyword',
  title: product.title,
  hasReferenceImage: Boolean(product.image),
  referenceSource: product.referenceSource || null,
  productCandidates:
    product.productCandidates?.length || 0,
  discoveryIssue: product.discoveryIssue || null
}));

  if (!product.image) return analyze(product);
  const key = 'vision:' + hash(product.image + '|' + (process.env.GEMINI_MODEL || 'default'));
  if (!product.cacheHit) {
    const cached = await pool.query("SELECT value FROM product_cache WHERE cache_key=$1 AND updated_at > now()-interval '7 days'", [key]);
    if (cached.rows[0]?.value?.visionVerified) return { ...product, ...cached.rows[0].value, image: product.image, cacheHit: true };
  }
  const analyzed = await analyze(product);
  if (analyzed.visionVerified) {
    const value = { attributes: analyzed.attributes, queries: analyzed.queries, visionVerified: true, generatedDescription: analyzed.generatedDescription };
    await pool.query('INSERT INTO product_cache(cache_key,value) VALUES($1,$2) ON CONFLICT(cache_key) DO UPDATE SET value=EXCLUDED.value,updated_at=now()', [key, JSON.stringify(value)]);
  }
  
console.log(JSON.stringify({
  event: 'product_vision_ready',
  title: analyzed.title,
  hasReferenceImage: Boolean(analyzed.image),
  visionVerified: analyzed.visionVerified === true,
  visionIssue: analyzed.visionIssue || null
}));

  return analyzed;
}

export async function processSearch(job) {
  const id = job.id;
  try {
    await stage(id, 'Extracting and analyzing product');
    const product = await prepareProduct(job);
    await updateSearch(id, { product: JSON.stringify(product) });
    await stage(id, 'Collecting Instagram and Meta in parallel');
    const settled = await Promise.allSettled([runSource(id, 'instagram', product), runSource(id, 'meta', product)]);
    const results = [], previews = [], issues = [];
    settled.forEach((r, i) => {
      const platform = i === 0 ? 'instagram' : 'meta';
      if (r.status === 'fulfilled') { results.push(...r.value.chosen); previews.push(...r.value.candidatesPreview); issues.push(...r.value.issues); }
      else issues.push(`${platform}: ${String(r.reason?.message || 'Source failure').slice(0, 240)}`);
    });
    await stage(id, 'Saving unique results');
    const client = await pool.connect();
    let kept = [];
    try {
      await client.query('BEGIN');
      for (const video of results) {
        const insert = await client.query('INSERT INTO seen_videos(platform,identity,search_id,fingerprint) VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING RETURNING identity', [video.platform, video.identity, id, video.fingerprint]);
        if (insert.rowCount) kept.push(video);
      }
      await client.query('UPDATE searches SET status=$2,stage=$3,results=$4,issues=$5,candidate_previews=$6,updated_at=now() WHERE id=$1', [id, 'completed', 'Completed', JSON.stringify(kept), JSON.stringify(issues), JSON.stringify(previews)]);
      await client.query('COMMIT');
    } catch (e) { await client.query('ROLLBACK').catch(() => {}); throw e; }
    finally { client.release(); }
    console.log(JSON.stringify({ event: 'search_completed', searchId: id, verifiedCount: kept.length, previewCount: previews.length, issueCount: issues.length }));
  } catch (e) {
    await updateSearch(id, { status: 'failed', stage: 'Failed', error: String(e.message || e) });
    console.error(JSON.stringify({ event: 'search_failed', searchId: id, error: String(e.message || e) }));
  }
}
